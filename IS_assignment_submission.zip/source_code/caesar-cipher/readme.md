# Caesar Cipher

## Output

```
 ** Caesar Cipher ** 

1. Encrypt text.
2. Decrypt text.

Enter choice: 1

Enter text     : wonderful is caesar the great
Encrypted text : zrqghuixo lv fdhvdu wkh juhdw

```

```
 ** Caesar Cipher ** 

1. Encrypt text.
2. Decrypt text.

Enter choice: 2

Enter text     : zrqghuixo lv fdhvdu wkh juhdw
Decrypted text : wonderful is caesar the great

```