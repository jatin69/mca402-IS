# Hill Cipher

## Output

```text
Enter 3x3 matrix for key (It should be invertible) ( try all prime ):
1 2 3
5 7 11
13 17 19

Enter a 3 letter string:
usa

Encrypted string is: esu

Inverse Matrix is:
-2.25 0.541667 0.0416667 
2 -0.833333 0.166667 
-0.25 0.375 -0.125 

Decrypted string is: usa
```

```
Enter 3x3 matrix for key (It should be invertible) ( try all prime ):
9 22 9
1 2 4
22 44 5

Enter a 3 letter string: usa

Encrypted string is: eek

Inverse Matrix is:
-0.5 0.861446 0.210843 
0.25 -0.460843 -0.0813253 
0 0.26506 -0.0120482 

Decrypted string is: usa

```