# DES


## Supported Modes

- [X] ECB ( Electronice Code Book )
- [ ] CBC ( Cipher Block Chaining )
- [ ] CFB ( Cipher Feedback Mode  )
- [ ] OFB ( Output Feedback Mode  )
- [ ] CTR ( Counter Feedback Mode )

## Output

```
 ** Data Encryption Standard **

Enter Plaintext    : des is wonderful
Encyption Key HEX  : 133457799bbcdff1
Plain  Text   HEX  : 64657320697320776f6e64657266756c
Cipher Text   HEX  : 91c3243590b69b69abcb77dc24504a30

Decrypting message ... 
Plain Text: des is wonderful
```

```
 ** Data Encryption Standard **

Enter Plaintext    : but aes is better
Encyption Key HEX  : 133457799bbcdff1
Plain  Text   HEX  : 627574206165732069732062657474657200000000000000
Cipher Text   HEX  : 7ab83c5071406f63661c25d30fa2863db786e552098fec45

Decrypting message ... 
Plain Text: but aes is better
```