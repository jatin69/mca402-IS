# AES ( Advance Encryption Standard )

## Supported Modes

- [X] ECB ( Electronice Code Book )
- [X] CBC ( Cipher Block Chaining )
- [X] CFB ( Cipher Feedback Mode  )
- [ ] OFB ( Output Feedback Mode  )
- [ ] CTR ( Counter Feedback Mode )

## output

```
********** AES **************

Default Test : 

Plain text               : Thisisagoodday.
Plain text [HEX]         : 54686973697361676f6f646461792e

Encryption Key           : gjvhcbkjwerfgvervelcnwjcnekljcv
Encryption Key [HEX]     : 676a766863626b6a776572666776657276656c636e776a636e656b6c6a6376

Cipher text is           : 0��Wc~��筚
Cipher text is [HEX]     : 30851e9b6576347e8dce3a2e7ad9a

Decrypted text is        : Thisisagoodday.
Decrypted text is  [HEX] : 54686973697361676f6f646461792e

Plaintext == Decrypted Text 
AES Test Successful.



Custom Test : 

Enter Plaintext          : AES works.
Enter Key                : hahahahahhajhvdcbjlkcs

Plain text               : AES works.
Plain text [HEX]         : 41455320776f726b732e

Encryption Key           : hahahahahhajhvdcbjlkcs
Encryption Key [HEX]     : 68616861686168616868616a68766463626a6c6b6373

Cipher text is           : @V	H	ė�S����Fz�
Cipher text is [HEX]     : 40569489c497a153eaf983f4467ac5

Decrypted text is        : AES works.
Decrypted text is  [HEX] : 41455320776f726b732e

Plaintext == Decrypted Text 
AES Test Successful.
```
